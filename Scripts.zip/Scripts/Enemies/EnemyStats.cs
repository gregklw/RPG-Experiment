﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    public string characterName;
    public int exp;
    public int hp;
    public int damage;
    public float movespeed;
}
