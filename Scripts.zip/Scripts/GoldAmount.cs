﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldAmount : MonoBehaviour, IPoolObjectInitialize
{
    public int amount;

    public void InitializePoolObject()
    {
        
    }
}
