﻿using UnityEngine;

public interface IPoolObjectInitialize
{
    void InitializePoolObject();
}
